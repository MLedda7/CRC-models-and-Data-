# Replication package

**Unraveling Evolutionary Dynamics: Insights from *In Silico* Experiments on Selective Mechanisms in Controlled Environments**
M. Ledda, A. Pluchino, M. Ragusa

This folder holds everything needed to reproduce the simulations, the data and Figures 4–9 of the paper:

- the agent-based model;
- the scripts that run the 100 simulations;
- the complete simulation output;
- the R code for the Price-equation analysis and the figures.

```
replication/
├── README.md                      this file
├── model/
│   └── colonic-crypt-model.html   the model: a single HTML file that runs in any web browser
├── simulation/
│   ├── run_simulation.js          runs one replicate without a browser (Node.js), using the model file above
│   ├── jobs.txt                   the 100 runs of the paper, one per line
│   ├── combine_runs.js            merges the per-run files into ../data
│   ├── run_log.txt                log of the runs used in the paper
│   └── raw/run001 … run100/       per-run output (same files as data/, one run each)
├── data/                          the data used in the paper (all 100 runs)
│   ├── summary.csv
│   ├── timeseries.csv
│   ├── price_windows.csv
│   ├── genotype_windows.csv
│   └── regression_windows.csv
└── analysis/
    ├── analysis.R                 Price-equation analysis, tables and figures
    └── output/
        ├── figures/               fig1 … fig6 (PDF and 300 dpi PNG) = Figures 4–9 of the paper
        └── tables/                every number shown in the figures, as CSV
```

## 1. Quick start

You do not need to rerun the simulations to check the figures: `data/` already holds the output used in the paper.

```bash
cd analysis
Rscript analysis.R          # about 20 s; writes output/figures and output/tables
```

**Requirements:** R ≥ 4.1 with `dplyr`, `tidyr`, `readr`, `ggplot2` and `patchwork`. The paper used R 4.3.3 and ggplot2 3.4.4. The PDF figures are written with `cairo_pdf`, so R must be built with cairo support (the default on most systems).

**To rerun everything from scratch** you need Node.js ≥ 18 (the paper used 22.22). This takes about 12 minutes on a laptop with two parallel jobs (the μ = 10⁻² runs are fast, since most reach the cell cap within a few windows or less).

```bash
cd simulation
rm -rf raw ../data/*.csv
xargs -P 2 -L 1 node run_simulation.js < jobs.txt > run_log.txt   # 100 runs, 2 at a time
node combine_runs.js                                              # writes ../data/*.csv
cd ../analysis && Rscript analysis.R
```

The model is deterministic for a given seed, so the rerun reproduces `data/` exactly. Only the order of the lines in `run_log.txt` may change, because the runs are executed in parallel.

## 2. The model

`model/colonic-crypt-model.html` is the complete model. Open it in a web browser (no installation or internet connection needed) to:

- run it interactively;
- inspect single cells;
- run batches of replicates from the **Replicate runs** panel, which saves a zip with the same CSV files as `data/`.

`run_simulation.js` does not contain its own copy of the model. It reads the simulation and batch code directly from the HTML file and runs it in Node.js, so the runs use exactly the published model.

### Settings of the 100 runs

| Setting | Value |
|---|---|
| Mutation probability μ (per allele per division) | 10⁻⁹, 10⁻⁶, 10⁻⁵, 10⁻⁴, 10⁻² |
| Mitosis condition | `differential`: mean mitosis time 24 h; 12 h for cells with a mutated *KRAS* copy; 10 h for tumoral cells. `uniform`: 24 h for every cell |
| Seeds | 1–10 for every scenario (Mulberry32 generator) |
| Burn-in | 120 h (not analysed) |
| Price windows | consecutive, 48 h long; window *k* runs from t₁ = 120 + 48k to t₂ = t₁ + 48 |
| Time series sampling | every 48 h, at the window boundaries |
| Stop conditions | 8,760 h (one year) or 10,000 cells; the stop at 75% transit-amplifying cells is **off** |
| Immune cells produced per hotspot per hour | 1 |
| Immune threshold (neoplastic cells per patch) | 5 |
| Hypoxic threshold (neoplastic cells per patch) | 5 |
| NK speed | 39 patches/h (6–7 µm/min, persistent random walk) |
| Immune cell kills before death / lifespan | 5 kills / 10 h |
| TP53 apoptosis threshold | 5 regulatory hits (of 12), only in cells with *TP53* [0 0] |
| Stem niche | for each gene, a new cell is heterozygous with probability 0.5 (otherwise wild type) |

Every other parameter is the model default.

The lines of `jobs.txt` read `run mutation_exponent mitosis seed immune_per_hotspot hypoxia_threshold`. For example, `21 6 differential 1 1 5` is run 21: μ = 10⁻⁶, differential mitosis, seed 1, 1 immune cell per hotspot, hypoxic threshold 5. Runs are numbered as follows:

| Runs | μ | Mitosis |
|---|---|---|
| 1–10 | 10⁻⁹ | differential |
| 11–20 | 10⁻⁹ | uniform |
| 21–30 | 10⁻⁶ | differential |
| 31–40 | 10⁻⁶ | uniform |
| 41–50 | 10⁻⁵ | differential |
| 51–60 | 10⁻⁵ | uniform |
| 61–70 | 10⁻⁴ | differential |
| 71–80 | 10⁻⁴ | uniform |
| 81–90 | 10⁻² | differential |
| 91–100 | 10⁻² | uniform |

**Run lengths:**

- At μ = 10⁻⁹ every run lasts one year (180 windows).
- At μ = 10⁻⁶ with differential mitosis, 3 runs reach 10,000 cells before one year.
- At μ = 10⁻⁵ every run reaches 10,000 cells, between those two regimes.
- At μ = 10⁻⁴ every run reaches 10,000 cells: between 259 and 541 h with differential mitosis (2–8 windows), and between 1,338 and 3,185 h with uniform mitosis (25–63 windows).
- At μ = 10⁻² with uniform mitosis every run reaches 10,000 cells within 2–3 windows after the burn-in. With differential mitosis, the fast *KRAS*-driven proliferation (12 h mitosis time) reaches the cell cap at 133–145 h in all 10 seeds — **inside the first window** (120–168 h), 13–25 h after the burn-in.

If a run stops inside a window, that window is normally discarded — **except** when it is the run's first window, i.e. the run would otherwise contribute 0 windows. In that one case the model writes a single fallback window covering the whole burn-in-to-stop interval, so the combination is not simply missing from the data. This rule is general (it is implemented once, for any run, not per scenario); in this dataset it is triggered only by the 10 μ = 10⁻² differential runs, each contributing exactly 1 window of 13–25 h instead of the usual 48 h. Because the window is so much shorter, fitness and the Price terms for this combination are **not on the same scale** as the rest of the data (there is much less time for divisions, deaths or selection to accumulate) — see `analysis/analysis.R` and the paper's Methods section for how this is flagged in the figures.

## 3. How the data are produced: ancestors and descendants

Every cell has an ancestor tag, `anc`. At the start of each window (t₁) every living cell gets `anc` = its own ID and becomes an ancestor. Daughter cells copy `anc` from their mother. Cells entering from the stem niche during the window get `anc = 0` and are excluded.

At the end of the window (t₂), for ancestor *i*:

- **zᵢ**: its trait value at t₁;
- **wᵢ**: the number of living cells with `anc = i` at t₂. This count includes the ancestor itself if it is alive (a dividing cell keeps its ID), and is 0 if the lineage died out or left the crypt;
- **z′ᵢ**: the mean trait of those cells, with δᵢ = z′ᵢ − zᵢ.

At t₂ the tags are reassigned and the next window opens at the same hour. Windows are normally 48 h; if a run stops before a window reaches 48 h, that window is discarded — except a run's very first window, which is instead closed early at the run's actual stop time so the run is not left with zero windows (see "Run lengths" above). This only happens for the 10 μ = 10⁻² differential runs in this dataset.

With N ancestors, all averages divide by N (not N − 1):

- w̄ = Σwᵢ/N
- z̄ = Σzᵢ/N
- cov(w,z) = Σ(wᵢ − w̄)(zᵢ − z̄)/N
- E(wδ) = Σwᵢδᵢ/N
- z̄′ = Σwᵢz′ᵢ / Σwᵢ
- Δz̄ = z̄′ − z̄

The Price equation, Δz̄ = [cov(w,z) + E(wδ)] / w̄, holds exactly. Δz̄ is computed directly from the cells, and the column `<trait>_check` records the difference. The largest |check| in `data/` is 1.9 × 10⁻¹³.

### Traits

| Trait | Values | Meaning |
|---|---|---|
| `apc`, `kras`, `tp53` | 0, 1, 2 | number of mutated alleles of each driver gene |
| `physiological`, `pre_adenoma`, `adenoma`, `tumoral` | 0/1 | typology indicator; transit-amplifying and differentiated cells are both `physiological`. Δz̄ is the change in the frequency of the typology |
| `rate` | ≈ 0.86–3 | programmed division rate, 24 / mitosis time of the cell (h), in divisions per 24 h |
| `phi` | 0–6 | `apc + kras + tp53`, the phenotypic value of the previous version of the paper (input of Figure 9) |

### Genotype-effect coding (used for the direct/indirect decomposition)

| Variable | 1 when |
|---|---|
| `apc11` | *APC* is [1 1] |
| `krasmut` | *KRAS* has at least one mutated copy ([1 0], [0 1] or [1 1]) |
| `tp5311` | *TP53* is [1 1] |

## 4. Data dictionary

Every file starts with the same four columns:

| Column | Meaning |
|---|---|
| `run` | run number (1–100, see `jobs.txt`) |
| `mutation_probability` | `1e-9`, `1e-6`, `1e-5`, `1e-4` or `1e-2` (read it as text) |
| `mitosis` | `differential` or `uniform` |
| `seed` | random seed |

### `summary.csv`: one row per run

| Column | Meaning |
|---|---|
| `burn_in_h` | burn-in length (120) |
| `end_h` | hour at which the run stopped |
| `stop_reason` | why the run stopped (one year completed, or 10,000 cells) |
| `cells`, `transit`, `differentiated`, `pre_adenoma`, `adenoma`, `tumoral` | number of cells at the end, total and by type |
| `immune` | immune cells alive at the end |
| `first_adenoma_h`, `first_tumoral_h` | first hour with at least one adenoma / tumoral cell (empty if never) |
| `peak_neoplastic` | largest number of neoplastic cells at any hour |
| `divisions` | divisions after the burn-in |
| `deaths_lifespan` | physiological and neoplastic cells that reached their lifespan, after the burn-in |
| `deaths_removed` | cells removed by a dividing neighbour, after the burn-in |
| `exits_mouth` | cells that left the crypt from the top, after the burn-in |
| `deaths_hypoxia`, `deaths_immune` | deaths by hypoxia / killed by immune cells, after the burn-in |
| `deaths_tp53` | TP53-mediated apoptosis (regulatory hits), after the burn-in |
| `deaths_tumoral_lifespan` | tumoral cells that reached their lifespan, after the burn-in |
| `mean_regulatory_hits` | mean number of regulatory-gene hits per cell at the end |

### `timeseries.csv`: one row per run and sampling hour (every 48 h from hour 120)

| Column | Meaning |
|---|---|
| `hour` | model hour |
| `cells` … `immune` | number of cells at that hour, as in `summary.csv` |
| `divisions` … `deaths_tumoral_lifespan` | events **in the 48 h since the previous row** |
| `apc_wt`, `apc_het`, `apc_mut` (same for `kras`, `tp53`) | fraction of cells with genotype [0 0], heterozygous, [1 1] |
| `mean_regulatory_hits` | mean regulatory hits per cell |

### `price_windows.csv`: one row per run and window (input of Figures 6 and 7)

| Column | Meaning |
|---|---|
| `window` | window number *k* (0, 1, 2, …) |
| `t1_h`, `t2_h` | start and end of the window (h). Normally `t2_h - t1_h` = 48; for the 10 μ = 10⁻² differential runs the first (and only) window is closed early by the fallback rule described above, so `t2_h - t1_h` is 13–25 h for those rows only |
| `n_ancestors` | N, cells alive at t₁ |
| `n_with_desc` | ancestors with wᵢ > 0 |
| `n_descendants` | tagged cells alive at t₂ (Σwᵢ) |
| `n_untagged` | cells at t₂ that entered from the stem niche during the window (descriptive only) |
| `w_mean` | w̄ = n_descendants / n_ancestors |
| `<trait>_mean_anc` | z̄, mean of the trait over the ancestors |
| `<trait>_var_anc` | var(z) over the ancestors |
| `<trait>_cov_w` | cov(w, z) |
| `<trait>_e_wdelta` | E(wδ) |
| `<trait>_mean_desc` | z̄′, mean over the tagged descendants |
| `<trait>_delta` | Δz̄ = z̄′ − z̄, computed directly |
| `<trait>_check` | [cov(w,z) + E(wδ)] / w̄ − Δz̄ (zero up to rounding) |

The seven `<trait>_…` columns repeat for each trait, in this order: `apc`, `kras`, `tp53`, `physiological`, `pre_adenoma`, `adenoma`, `tumoral`, `rate`, `phi`.

- Selection term S = `<trait>_cov_w / w_mean`
- Transmission term T = `<trait>_e_wdelta / w_mean`

### `genotype_windows.csv`: one row per run, window and class (input of Figures 4 and 5)

| Column | Meaning |
|---|---|
| `window`, `t1_h`, `t2_h` | as above |
| `gene` | `APC`, `KRAS`, `TP53`, `typology`, `mitosis_time_h` or `phi` |
| `class` | for genes: `00`, `het`, `11`. For `typology`: `physiological`, `pre_adenoma`, `adenoma`, `tumoral`. For `mitosis_time_h`: the mitosis time of the cell in hours (an integer). For `phi`: `apc + kras + tp53` in allele counts, `0`–`6` (input of Figure 9) |
| `n_t1` | ancestors in this class at t₁ |
| `desc_t2` | tagged descendants at t₂ of the ancestors in this class, whatever their class at t₂ |
| `n_t2` | tagged cells in this class at t₂ |
| `freq_t1` | n_t1 / n_ancestors |
| `freq_t2` | n_t2 / n_descendants |
| `w_class` | desc_t2 / n_t1, fitness of the class (empty when n_t1 = 0) |

`desc_t2` and `n_t2` differ only through mutation.

### `regression_windows.csv`: one row per run and window (input of Figure 8)

| Column | Meaning |
|---|---|
| `window`, `t1_h`, `t2_h`, `n_ancestors`, `w_mean` | as above |
| `mean_apc11`, `mean_krasmut`, `mean_tp5311` | mean of the three genotype-effect variables over the ancestors |
| `var_apc11`, `var_krasmut`, `var_tp5311` | their variances (diagonal of **P**) |
| `cov_apc11_krasmut`, `cov_apc11_tp5311`, `cov_krasmut_tp5311` | their covariances (off-diagonal of **P**) |
| `cov_w_apc11`, `cov_w_krasmut`, `cov_w_tp5311` | covariance of fitness with each variable |

All (co)variances divide by N.

## 5. The analysis (`analysis/analysis.R`)

The script reads `data/` and writes every figure and table. The paper's figures correspond to the script's output as follows:

| Paper | File | Content |
|---|---|---|
| Figure 4 | `fig1_fitness_by_typology` | fitness of each typology |
| Figure 5 | `fig2_fitness_by_division_rate` | fitness against the programmed division rate |
| Figure 6 | `fig3_price_terms_genes` | Price terms for the allele counts |
| Figure 7 | `fig4_price_terms_typology` | Price terms for the typology indicators |
| Figure 8 | `fig5_direct_indirect_selection` | direct and indirect selection |
| Figure 9 | `fig6_fitness_by_phi` | fitness against the phenotypic value φ, μ = 10⁻⁵ only: linear vs. cubic polynomial fit |

### Procedure

1. **Identity check.** The script prints the largest |`<trait>_check`| and writes `tables/identity_check.csv`.
2. **Price terms (Figures 6, 7).** For each run, S, T, Δz̄ and var(z) are averaged over the run's windows. For each scenario, the figure shows the mean and SD across the 10 runs. Tables: `price_terms_per_run.csv`, `price_terms_by_scenario.csv`.
3. **Fitness by typology (Figure 4).** For each run and typology, `n_t1` and `desc_t2` are summed over the windows, and w = Σdesc_t2 / Σn_t1. The value is used only if the typology has at least 20 ancestors in that run. The figure shows the mean ± SD across runs, and only typologies present in at least 3 runs. Table: `fitness_by_typology.csv`.
4. **Fitness and division rate (Figure 5).** The `mitosis_time_h` classes are pooled over windows and runs. Rate = 24 / mitosis time, and classes with fewer than 200 ancestors are dropped. The line is the least-squares fit weighted by the number of ancestors. S is the run-averaged selection term of `rate`. Tables: `fitness_by_division_rate.csv`, `fitness_by_division_rate_fit.csv`.
5. **Direct and indirect selection (Figure 8)** (Lande & Arnold 1983, *Evolution* 37:1210). For each run:
   - **P** (the 3×3 covariance matrix of `apc11`, `krasmut`, `tp5311`) and **s** = `cov_w_*` / `w_mean` are averaged over the windows;
   - **β** = **P**⁻¹**s**;
   - for gene *j*: direct = P_jj β_j, indirect = s_j − direct.

   A run is used only if each of the three variances, averaged over its windows, is at least 10⁻⁶. The figure shows only scenarios with at least 3 such runs; μ = 10⁻⁹ has no *APC* or *TP53* [1 1] cells, and μ = 10⁻⁶ with uniform mitosis has only 2 usable runs. Tables: `regression_per_run.csv`, `regression_by_scenario.csv`.
6. **Fitness against φ, linear vs. polynomial fit (Figure 9).** Restricted to μ = 10⁻⁵ (both mitosis conditions). The `phi` classes (`gene = "phi"` in `genotype_windows.csv`) are pooled over windows and runs, as in step 4, and classes with fewer than 200 ancestors are dropped. For each mitosis condition, a linear and a cubic-polynomial regression of w on φ are fit, both weighted by the number of ancestors (`lm(w ~ phi, weights = n_t1)` and `lm(w ~ poly(phi, 3, raw = TRUE), weights = n_t1)`); the polynomial degree is set by `POLY_DEGREE` at the top of that section of the script. Tables: `fitness_by_phi.csv`, `fitness_by_phi_fit.csv` (the two fitted curves, for plotting).

The thresholds (`MIN_RUNS`, `MIN_ANC_RUN`, `MIN_ANC_BIN`, `POLY_DEGREE`), the colours and the scenario list are set at the top of the script.

Steps 2–4 pool `n_t1`/`desc_t2` (or the window-level S, T) by summation, regardless of each window's duration, so the 13–25 h fallback windows of the μ = 10⁻² differential runs (see "Run lengths", §2, and §3) enter Figures 4–7 on the same footing as everyone else's 48 h windows. The resulting w, S and T values for that one scenario are real, but — being accumulated over a much shorter interval — are not on the same timescale as the rest of the figure; the paper's captions flag this.

## 6. Licence and citation

[To be completed by the authors: licence, repository URL and DOI.]
