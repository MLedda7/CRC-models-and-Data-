# =============================================================================
# Price-equation analysis of the Colonic Crypt Model
# Reads the model output in ../data and writes figures and tables to ./output
#
# Usage (from this folder):  Rscript analysis.R
# Requires R >= 4.1 and the packages dplyr, tidyr, readr, ggplot2, patchwork
# =============================================================================

suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(readr); library(ggplot2); library(patchwork)
})

data_dir <- file.path("..", "data")
out_fig  <- file.path("output", "figures")
out_tab  <- file.path("output", "tables")
dir.create(out_fig, recursive = TRUE, showWarnings = FALSE)
dir.create(out_tab, recursive = TRUE, showWarnings = FALSE)

# ---- Settings ---------------------------------------------------------------
MU_LEVELS   <- c("1e-9", "1e-6", "1e-5", "1e-4", "1e-2")   # mutation probabilities analysed
MU_LABELS   <- c("1e-9" = "10^-9", "1e-6" = "10^-6", "1e-5" = "10^-5", "1e-4" = "10^-4", "1e-2" = "10^-2")
COND_LEVELS <- c("differential", "uniform")              # mitosis conditions
COND_FILL   <- c(differential = "#D9A300", uniform = "#4A4A4A")   # gold, dark grey
COND_LABEL  <- c(differential = "Differential mitosis (24 / 12 KRAS / 10 tumoral h)",
                 uniform      = "Uniform mitosis (24 h)")
GENES       <- c("apc", "kras", "tp53")
GENE_LABEL  <- c(apc = "APC", kras = "KRAS", tp53 = "TP53")
TYPO        <- c("physiological", "pre_adenoma", "adenoma", "tumoral")
TYPO_LABEL  <- c(physiological = "Physiological", pre_adenoma = "Pre-adenoma",
                 adenoma = "Adenoma", tumoral = "Tumoral")
MIN_RUNS    <- 3      # a scenario value is shown only if at least this many runs contribute
MIN_ANC_RUN <- 20     # a typology's per-capita fitness in a run needs at least 20 ancestors (pooled over windows)
MIN_ANC_BIN <- 200    # a mitosis-time class in Figure 2 needs at least 200 ancestors (pooled over runs)

theme_paper <- theme_bw(base_size = 9) +
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_line(colour = "grey90", linewidth = 0.3),
        panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5),
        strip.background = element_rect(fill = "white", colour = "black", linewidth = 0.5),
        legend.position = "top", legend.title = element_blank(),
        plot.title = element_text(size = 9, face = "plain", hjust = 0.5))
mu_scale <- scale_x_discrete(labels = function(x) parse(text = MU_LABELS[x]))
# facet labels in plotmath: mu == 10^-9 and 'differential mitosis'
add_facet_labels <- function(d) d %>%
  mutate(mu_lab = factor(paste0("mu == ", MU_LABELS[as.character(mutation_probability)]),
                         paste0("mu == ", MU_LABELS[MU_LEVELS])),
         mit_lab = factor(paste0("'", mitosis, " mitosis'"), paste0("'", COND_LEVELS, " mitosis'")))
save_fig <- function(p, name, w, h) {
  ggsave(file.path(out_fig, paste0(name, ".pdf")), p, width = w, height = h, device = cairo_pdf)
  ggsave(file.path(out_fig, paste0(name, ".png")), p, width = w, height = h, dpi = 300, bg = "white")
}

# ---- Data -------------------------------------------------------------------
rd <- function(f) {                       # read the scenario columns (and 'class', where present) as text
  types <- cols(mutation_probability = "c", mitosis = "c", .default = col_guess())
  if ("class" %in% names(read_csv(file.path(data_dir, f), n_max = 0, show_col_types = FALSE))) types$cols$class <- col_character()
  read_csv(file.path(data_dir, f), show_col_types = FALSE, col_types = types)
}
summary_runs <- rd("summary.csv")
pw <- rd("price_windows.csv"); gw <- rd("genotype_windows.csv"); rw <- rd("regression_windows.csv")
scen <- function(d) d %>%
  mutate(mutation_probability = factor(mutation_probability, MU_LEVELS),
         mitosis = factor(mitosis, COND_LEVELS)) %>%
  filter(!is.na(mutation_probability))
pw <- scen(pw); gw <- scen(gw); rw <- scen(rw)

# ---- 0. Identity check: (cov + E(w delta)) / w_mean - delta must be zero ------
check <- pw %>% select(ends_with("_check")) %>% abs() %>% as.matrix()
write_csv(tibble(windows = nrow(pw), runs = n_distinct(pw$run), max_abs_check = max(check, na.rm = TRUE)),
          file.path(out_tab, "identity_check.csv"))

# ---- 1. Price terms per run (mean over the run's windows) ------------------
traits <- c(GENES, TYPO, "rate", "phi")
terms_long <- pw %>%
  select(run, mutation_probability, mitosis, seed, window, w_mean,
         matches(paste0("^(", paste(traits, collapse = "|"), ")_(cov_w|e_wdelta|delta|var_anc)$"))) %>%
  pivot_longer(-c(run, mutation_probability, mitosis, seed, window, w_mean),
               names_to = c("trait", "term"), names_pattern = paste0("^(", paste(traits, collapse = "|"), ")_(.*)$")) %>%
  mutate(value = case_when(term == "cov_w"    ~ value / w_mean,   # selection term, S
                           term == "e_wdelta" ~ value / w_mean,   # transmission term
                           TRUE ~ value),
         term = recode(term, cov_w = "selection", e_wdelta = "transmission", delta = "change", var_anc = "variance"))
per_run <- terms_long %>% group_by(run, mutation_probability, mitosis, seed, trait, term) %>%
  summarise(value = mean(value, na.rm = TRUE), windows = n(), .groups = "drop")
by_scen <- per_run %>% group_by(mutation_probability, mitosis, trait, term) %>%
  summarise(mean = mean(value), sd = sd(value), runs = n(), .groups = "drop") %>%
  mutate(mean = ifelse(runs >= MIN_RUNS, mean, NA), sd = ifelse(runs >= MIN_RUNS, sd, NA))
write_csv(per_run, file.path(out_tab, "price_terms_per_run.csv"))
write_csv(by_scen, file.path(out_tab, "price_terms_by_scenario.csv"))
S_of <- function(tr) by_scen %>% filter(trait == tr, term == "selection") %>% select(mutation_probability, mitosis, S = mean)

# ---- Bar-panel builder (Figures 3-5) -----------------------------------------
TERM_TITLE <- list(selection = expression("Selection, cov(w,z) /" ~ bar(w)),
                   transmission = expression("Transmission, E(w" * delta * ") /" ~ bar(w)),
                   change = expression("Change in mean," ~ Delta * bar(z)),
                   variance = "Variance, var(z)")
bar_panel <- function(d, title = NULL, ylab = NULL, xlab = NULL) {
  # keep every scenario on the axis; a scenario with fewer than MIN_RUNS runs gets an invisible bar of height 0
  d <- d %>% complete(mutation_probability, mitosis) %>%
    mutate(shown = !is.na(mean), y = ifelse(shown, mean, 0), lo = mean - sd, hi = mean + sd)
  ggplot(d, aes(mutation_probability, y, fill = mitosis, group = mitosis)) +
    geom_hline(yintercept = 0, linewidth = 0.3) +
    geom_col(aes(alpha = shown), position = position_dodge(0.8), width = 0.75) +
    geom_errorbar(aes(ymin = lo, ymax = hi), position = position_dodge(0.8), width = 0.25, linewidth = 0.3, na.rm = TRUE) +
    scale_alpha_manual(values = c(`TRUE` = 1, `FALSE` = 0), guide = "none") +
    scale_fill_manual(values = COND_FILL, labels = COND_LABEL, drop = FALSE) +
    mu_scale + labs(title = title, y = ylab, x = xlab) + theme_paper
}
terms_figure <- function(trs, labels, terms = names(TERM_TITLE)) {
  ps <- list()
  for (i in seq_along(trs)) for (j in seq_along(terms)) {
    d <- by_scen %>% filter(trait == trs[i], term == terms[j])
    ps[[length(ps) + 1]] <- bar_panel(d, title = if (i == 1) TERM_TITLE[[terms[j]]] else NULL,
                                      ylab = if (j == 1) labels[i] else NULL,
                                      xlab = if (i == length(trs)) "Mutation probability" else NULL)
  }
  wrap_plots(ps, ncol = length(terms), guides = "collect") & theme(legend.position = "bottom")
}

# ---- Figure 1: per-capita fitness by typology ----------------------------------
fit_typo_run <- gw %>% filter(gene == "typology") %>%
  group_by(run, mutation_probability, mitosis, class) %>%
  summarise(n_t1 = sum(n_t1), desc_t2 = sum(desc_t2), .groups = "drop") %>%
  filter(n_t1 >= MIN_ANC_RUN) %>% mutate(w = desc_t2 / n_t1)
fit_typo <- fit_typo_run %>% group_by(mutation_probability, mitosis, class) %>%
  summarise(w_mean = mean(w), w_sd = sd(w), runs = n(), .groups = "drop") %>%
  mutate(class = factor(class, TYPO)) %>%
  left_join(by_scen %>% filter(term == "selection", trait %in% TYPO) %>%
              select(mutation_probability, mitosis, class = trait, S = mean) %>% mutate(class = factor(class, TYPO)),
            by = c("mutation_probability", "mitosis", "class"))
write_csv(fit_typo, file.path(out_tab, "fitness_by_typology.csv"))
fit_typo_shown <- fit_typo %>% filter(runs >= MIN_RUNS)
p1 <- ggplot(add_facet_labels(fit_typo_shown), aes(class, w_mean)) +
  geom_hline(yintercept = 1, linewidth = 0.3, linetype = "dashed", colour = "grey40") +
  geom_errorbar(aes(ymin = w_mean - w_sd, ymax = w_mean + w_sd), width = 0.2, linewidth = 0.4, na.rm = TRUE) +
  geom_point(aes(fill = mitosis), shape = 21, size = 2.6, colour = "black", show.legend = FALSE) +
  geom_text(aes(y = w_mean + ifelse(is.na(w_sd), 0, w_sd), label = paste0("n = ", runs)), vjust = -0.7, size = 2.3) +
  scale_fill_manual(values = COND_FILL) +
  scale_y_continuous(expand = expansion(mult = c(0.08, 0.2))) +
  scale_x_discrete(drop = FALSE, labels = c(physiological = "Physiological", pre_adenoma = "Pre-adenoma", adenoma = "Adenoma", tumoral = "Tumoral")) +
  facet_grid(mu_lab ~ mit_lab, scales = "free_y", labeller = label_parsed) +
  labs(x = NULL, y = "Fitness w (descendants per ancestor in 48 h)") + theme_paper +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))
save_fig(p1, "fig1_fitness_by_typology", 5.4, 8.8)

# ---- Figure 2: fitness against programmed division rate ---------------------------
fit_rate <- gw %>% filter(gene == "mitosis_time_h") %>%
  mutate(mitosis_time_h = as.numeric(class), rate = 24 / mitosis_time_h) %>%
  group_by(mutation_probability, mitosis, mitosis_time_h, rate) %>%
  summarise(n_t1 = sum(n_t1), desc_t2 = sum(desc_t2), .groups = "drop") %>%
  filter(n_t1 >= MIN_ANC_BIN) %>% mutate(w = desc_t2 / n_t1)
# least-squares line through the classes weighted by their number of ancestors (= the slope of w on the trait)
fit_line <- fit_rate %>% group_by(mutation_probability, mitosis) %>%
  filter(n() > 1) %>%
  summarise(beta = sum(n_t1 * (rate - weighted.mean(rate, n_t1)) * (w - weighted.mean(w, n_t1))) /
                   sum(n_t1 * (rate - weighted.mean(rate, n_t1))^2),
            a = weighted.mean(w, n_t1) - beta * weighted.mean(rate, n_t1),
            xmin = min(rate), xmax = max(rate), .groups = "drop") %>%
  left_join(S_of("rate"), by = c("mutation_probability", "mitosis"))
write_csv(fit_rate, file.path(out_tab, "fitness_by_division_rate.csv"))
write_csv(fit_line, file.path(out_tab, "fitness_by_division_rate_fit.csv"))
p2 <- ggplot(add_facet_labels(fit_rate), aes(rate, w)) +
  geom_segment(data = add_facet_labels(fit_line), aes(x = xmin, xend = xmax, y = a + beta * xmin, yend = a + beta * xmax),
               colour = "black", linewidth = 0.6) +
  geom_point(aes(size = n_t1, fill = mitosis), shape = 21, colour = "black", stroke = 0.3, show.legend = FALSE) +
  scale_fill_manual(values = COND_FILL) +
  geom_text(data = add_facet_labels(fit_line), aes(x = Inf, y = -Inf, label = sprintf("S = %.3f", S)), hjust = 1.1, vjust = -0.6, size = 2.8) +
  scale_size_area(max_size = 4, guide = "none") +
  facet_grid(mu_lab ~ mit_lab, scales = "free_x", labeller = label_parsed) +
  labs(x = "Programmed division rate (divisions per 24 h)", y = "Fitness w (descendants per ancestor in 48 h)") + theme_paper
save_fig(p2, "fig2_fitness_by_division_rate", 5.4, 8.8)

# ---- Figure 3: Price terms, genes (trait = mutated allele count) -----------------
save_fig(terms_figure(GENES, GENE_LABEL[GENES]), "fig3_price_terms_genes", 9, 5.4)

# ---- Figure 4: Price terms, typology (trait = 0/1 indicator) -----------------
save_fig(terms_figure(TYPO, TYPO_LABEL[TYPO]), "fig4_price_terms_typology", 9, 6.8)

# ---- Figure 5: direct and indirect selection (genotype-effect coding) ----------
# Per window: P = covariance matrix of (APC [1 1], KRAS mutated, TP53 [1 1]) over the ancestors,
# s = cov(w, effects) / w_mean. Per run: average P and s over the windows, beta = P^-1 s,
# direct part of gene j = P_jj * beta_j, indirect part = s_j - direct part.
reg_run <- rw %>% group_by(run, mutation_probability, mitosis, seed) %>% group_modify(function(d, k) {
  P <- matrix(c(mean(d$var_apc11), mean(d$cov_apc11_krasmut), mean(d$cov_apc11_tp5311),
                mean(d$cov_apc11_krasmut), mean(d$var_krasmut), mean(d$cov_krasmut_tp5311),
                mean(d$cov_apc11_tp5311), mean(d$cov_krasmut_tp5311), mean(d$var_tp5311)), 3, 3)
  s <- c(mean(d$cov_w_apc11 / d$w_mean), mean(d$cov_w_krasmut / d$w_mean), mean(d$cov_w_tp5311 / d$w_mean))
  if (min(diag(P)) < 1e-6)                                   # an effect absent in this run: no regression
    return(tibble(gene = character(), total = numeric(), direct = numeric(), indirect = numeric(),
                  beta = numeric(), windows = integer()))
  beta <- solve(P, s); direct <- diag(P) * beta
  tibble(gene = GENES, total = s, direct = direct, indirect = s - direct, beta = beta, windows = nrow(d))
}) %>% ungroup()
reg_scen <- reg_run %>% pivot_longer(c(total, direct, indirect), names_to = "term") %>%
  group_by(mutation_probability, mitosis, gene, term) %>%
  summarise(mean = mean(value), sd = sd(value), runs = n(), .groups = "drop") %>%
  mutate(mean = ifelse(runs >= MIN_RUNS, mean, NA), sd = ifelse(runs >= MIN_RUNS, sd, NA)) %>%
  complete(mutation_probability, mitosis, gene, term)
write_csv(reg_run, file.path(out_tab, "regression_per_run.csv"))
write_csv(reg_scen, file.path(out_tab, "regression_by_scenario.csv"))
EFF_LABEL <- c(apc = "APC [1 1]", kras = "KRAS mutated", tp53 = "TP53 [1 1]")
REG_TITLE <- list(total = "Total selection, S", direct = expression("Direct," ~ P[jj] * beta[j]), indirect = "Indirect")
ps <- list()
for (i in seq_along(GENES)) for (j in seq_along(REG_TITLE)) {
  d <- reg_scen %>% filter(gene == GENES[i], term == names(REG_TITLE)[j])
  ps[[length(ps) + 1]] <- bar_panel(d, title = if (i == 1) REG_TITLE[[j]] else NULL, ylab = if (j == 1) EFF_LABEL[GENES[i]] else NULL,
                                    xlab = if (i == length(GENES)) "Mutation probability" else NULL)
}
p5 <- wrap_plots(ps, ncol = 3, guides = "collect") & theme(legend.position = "bottom")
save_fig(p5, "fig5_direct_indirect_selection", 7.5, 5.4)

# ---- Figure 6: fitness against phi (sum of mutated gene copies), mu = 1e-5 --------
# Redoes the polynomial-fit figure dropped from the previous version, with the present
# model's phenotypic value phi = (mutated copies of APC) + (KRAS) + (TP53), 0-6, and a
# single simulated scenario (mu = 1e-5, both mitosis conditions), as requested.
POLY_DEGREE <- 3
fit_phi <- gw %>% filter(gene == "phi", mutation_probability == "1e-5") %>%
  mutate(phi = as.numeric(class)) %>%
  group_by(mitosis, phi) %>%
  summarise(n_t1 = sum(n_t1), desc_t2 = sum(desc_t2), .groups = "drop") %>%
  filter(n_t1 >= MIN_ANC_BIN) %>% mutate(w = desc_t2 / n_t1)
write_csv(fit_phi, file.path(out_tab, "fitness_by_phi.csv"))

poly_curve <- fit_phi %>% group_by(mitosis) %>% group_modify(function(d, k) {
  if (nrow(d) < POLY_DEGREE + 2 || length(unique(d$phi)) <= POLY_DEGREE) return(tibble())
  fit_lin  <- lm(w ~ phi, data = d, weights = n_t1)
  fit_poly <- lm(w ~ poly(phi, POLY_DEGREE, raw = TRUE), data = d, weights = n_t1)
  xx <- seq(min(d$phi), max(d$phi), length.out = 100)
  tibble(phi = xx,
         linear = as.numeric(predict(fit_lin, newdata = tibble(phi = xx))),
         poly   = as.numeric(predict(fit_poly, newdata = tibble(phi = xx))))
}) %>% ungroup() %>%
  pivot_longer(c(linear, poly), names_to = "fit", values_to = "w")
write_csv(poly_curve, file.path(out_tab, "fitness_by_phi_fit.csv"))

MIT_LABEL <- c(differential = "Differential mitosis", uniform = "Uniform mitosis")
p6 <- ggplot(fit_phi, aes(phi, w)) +
  geom_point(aes(size = n_t1, fill = mitosis), shape = 21, colour = "black", stroke = 0.3, show.legend = FALSE) +
  geom_line(data = poly_curve, aes(phi, w, linetype = fit), colour = "black", linewidth = 0.6) +
  scale_fill_manual(values = COND_FILL) +
  scale_linetype_manual(values = c(linear = "42", poly = "solid"),
                        labels = c(linear = "Linear", poly = paste0("Polynomial, degree ", POLY_DEGREE)),
                        name = NULL) +
  scale_size_area(max_size = 4, guide = "none") +
  scale_x_continuous(breaks = 0:6) +
  facet_wrap(~ mitosis, labeller = as_labeller(MIT_LABEL)) +
  labs(x = expression(phi ~ "(mutated copies of " * italic(APC) * " + " * italic(KRAS) * " + " * italic(TP53) * ")"),
       y = "Fitness w (descendants per ancestor in 48 h)") +
  theme_paper
save_fig(p6, "fig6_fitness_by_phi", 7, 3.8)

cat("Done. Identity check, max |check| =", signif(max(check, na.rm = TRUE), 3), "\n")
