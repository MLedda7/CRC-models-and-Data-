// Runs ONE replicate of the Colonic Crypt Model with the model page's own simulation and batch code.
// The code is read from model/colonic-crypt-model.html at run time, so the runs use exactly the published model.
//
// Usage:  node run_simulation.js <run> <mutation_exponent> <mitosis> <seed> [immune_per_hotspot] [hypoxia_threshold]
//   run                 run number used in every output row (1, 2, ...)
//   mutation_exponent   e in a mutation probability of 10^-e per allele per division (9, 6, 4, ...)
//   mitosis             differential (24 / 12 KRAS / 10 tumoral h) or uniform (24 h for every cell)
//   seed                random seed (Mulberry32)
//   immune_per_hotspot  immune cells produced per hotspot per hour (default 1)
//   hypoxia_threshold   neoplastic cells per patch that trigger hypoxic death (default 5; "off" = no hypoxia)
// Writes simulation/raw/run<run>/{summary,timeseries,price_windows,genotype_windows,regression_windows}.csv,
// in the same format as the zip saved by the model page.
const fs = require("fs"), path = require("path");
const [run, e, mitosis, seed, imm = "1", hyp = "5"] = process.argv.slice(2);
if (!seed) { console.error("usage: node run_simulation.js <run> <mutation_exponent> <mitosis> <seed> [immune_per_hotspot] [hypoxia_threshold]"); process.exit(1); }
const html = fs.readFileSync(path.join(__dirname, "..", "model", "colonic-crypt-model.html"), "utf8");
const cut = (a, b) => html.slice(html.indexOf(a), html.indexOf(b));
const code = cut("const W = 50, H = 300;", "/* ---------- colours") + "\n" + cut("function snapshotCSV", "/* ---------- replicate runs") +
  "\nfunction selectDefault(){}\nlet batch = null;\n" + cut("const csvRow", "function renderBatch");
// Settings of the data protocol: burn-in 120 h, 48 h Price windows, time series every 48 h, one year or 10,000 cells, 75% stop off.
const CFG = { burn: 120, step: 48, win: 48, maxH: 8760, cap: 10000, taStop: false, geno: true, anc: false, events: false };
const body = `let running = false;\n${code}\n
  P.immPerHot = SET_IMM; P.hypThr = SET_HYP;
  batch = { active:true, queue:[job], i:0, run:null, cfg, sum:[], ts:[], pw:[], gw:[], rg:[], ancRows:[], cancel:false, saved:{}, zip:null };
  startNextRun();
  while (batch.run){ tick(); afterBatchTick(); if (stopped || hour >= batch.cfg.maxH) endRun(); }
  return { "summary.csv": [SUM_HEAD, ...batch.sum], "timeseries.csv": [TS_HEAD, ...batch.ts], "price_windows.csv": [PW_HEAD, ...batch.pw],
           "genotype_windows.csv": [GW_HEAD, ...batch.gw], "regression_windows.csv": [REG_HEAD, ...batch.rg] };`;
const t0 = Date.now();
const out = new Function("job", "cfg", "SET_IMM", "SET_HYP", body)(
  { n: +run, mutExp: +e, mitosis, seed: +seed }, CFG, +imm, hyp === "off" ? Infinity : +hyp);
const dir = path.join(__dirname, "raw", `run${String(run).padStart(3, "0")}`);
fs.mkdirSync(dir, { recursive: true });
for (const [f, rows] of Object.entries(out)) fs.writeFileSync(path.join(dir, f), rows.join("\n") + "\n");
console.log(`run ${run}: 1e-${e}, ${mitosis}, seed ${seed}: ${out["price_windows.csv"].length - 1} windows, ${((Date.now() - t0) / 1000).toFixed(1)} s`);
