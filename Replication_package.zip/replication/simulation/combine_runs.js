// Concatenates simulation/raw/run*/<file>.csv into data/<file>.csv (one header, rows in run order).
const fs = require("fs"), path = require("path");
const raw = path.join(__dirname, "raw"), out = path.join(__dirname, "..", "data");
const runs = fs.readdirSync(raw).filter(d => /^run\d+$/.test(d)).sort();
for (const f of ["summary.csv", "timeseries.csv", "price_windows.csv", "genotype_windows.csv", "regression_windows.csv"]){
  const lines = [];
  for (const r of runs){
    const L = fs.readFileSync(path.join(raw, r, f), "utf8").trim().split("\n");
    if (!lines.length) lines.push(L[0]); else if (L[0] !== lines[0]) throw new Error(`header mismatch in ${r}/${f}`);
    lines.push(...L.slice(1).filter(x => x));
  }
  fs.writeFileSync(path.join(out, f), lines.join("\n") + "\n");
  console.log(`data/${f}: ${lines.length - 1} rows from ${runs.length} runs`);
}
